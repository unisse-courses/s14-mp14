const genres = [
    {
        "_id": 1,
        "name": "Action"
    },
    {
        "_id": 2,
        "name": "Adventure"
    },
    {
        "_id": 3,
        "name": "Drama"
    },
    {
        "_id": 4,
        "name": "Horror"
    },
    {
        "_id": 5,
        "name": "Comedy"
    },
    {
        "_id": 6,
        "name": "Fantasy"
    },
    {
        "_id": 7,
        "name": "Sci-fi"
    },
    {
        "_id": 8,
        "name": "Shounen"
    },
    {
        "_id": 9,
        "name": "Slice of life"
    },
    {
        "_id": 10,
        "name": "Shoujo"
    }
]


export {
    genres
}