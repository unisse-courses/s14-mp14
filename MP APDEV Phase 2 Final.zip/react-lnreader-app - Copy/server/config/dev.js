module.exports = {
    mongoURI:'mongodb://127.0.0.1:27017/novels-app'
}
// module.exports = {
//     mongoURI:'mongodb+srv://group4:<group4>@cluster0-2bai3.mongodb.net/test?retryWrites=true&w=majority'
// }
