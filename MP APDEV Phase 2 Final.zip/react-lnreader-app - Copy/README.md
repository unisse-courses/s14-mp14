
To use this application, 

1. delete the node_modules folder in the root(main project folder) and client directory(delete the node_modules folder inside the client folder)
2. open the command prompt from the project folder(right click the address of the project folder then click edit address)
3. Type  " npm install " inside the root directory and client directory
4.  Close the command prompt
4. Re open the command prompt inside the project folder and type mongod
5. Open a new command prompt from the project folder and type mongo use novels-app
6. From here on out you may now deploy and run the application by openning the project folder and running the command prompt and typing the command "npm run dev"

Side note: the mongoURI is located in the file dev.js in server/config file directory

Authors and project developers: Pascual Jeremy,Pua Shaun,Ventucillo Ghael
CCAPDEV-S14 Group 4 Phase 3