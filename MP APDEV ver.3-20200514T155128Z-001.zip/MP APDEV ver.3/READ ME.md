To set up the program please go to project folder then open the command prompt from the folder by editing the address of the command prompt
in the address type cmd /*projectfolder name*/
the command prompt should open
in the command prompt type  the following in order of appearance:

npm install
npm install express
npm install handlebars
npm install express-handlebars
npm install -g nodemon
nodemon index.js or this if the previous command fails: node index.js or edit your path variable in envionment variables
C:\>npm install -g nodemon

Get prefix:

C:\>npm config get prefix

You will get output like following in your console:

C:\Users\Family\.node_modules_global

Copy it.

Set Path.
Go to Advance System Settings → Environment Variable → Click New (Under User Variables) → Pop up form will be displayed → Pass the following values:

variable name = path,
variable value = Copy output from your console

Now Run Nodemon:

C:\>nodemon .