// All imports needed here
const express = require('express');
const path = require('path');
const exphbs = require('express-handlebars');
const handlebars = require('handlebars');

// Creates the express application
const app = express();
const port = 3000;

/**
  Creates an engine called "hbs" using the express-handlebars package.
**/
app.engine( 'hbs', exphbs({
    extname: 'hbs', // configures the extension name to be .hbs instead of .handlebars
    defaultView: 'main', // this is the default value but you may change it to whatever you'd like
    layoutsDir: path.join(__dirname, '/views/layouts'), // Layouts folder
    partialsDir: path.join(__dirname, '/views/partials'), // Partials folder
  }));

// Setting the view engine to the express-handlebars engine we created
app.set('view engine', 'hbs');

// Routes
app.get('/', function(req, res) {
  res.render('home')
});

app.get('/log-in', function(req, res) {
  res.render('log-in')
});
app.get('/profile', function(req, res) {
  // data needed to insert to the page
  res.render('profile',{
    style: 'review.css',
    style2: 'post.css',
  });
});
app.get('/rankings', function(req, res) {
  // data needed to insert to the page
  res.render('ranking')
});
app.get('/two_pieces', function(req, res) {
 // data needed to insert to the page
  res.render('two pieces',{
  style: 'review.css',
  style2: 'post.css',
  });
});
app.get('/boruto_shippuden', function(req, res) {
  // data needed to insert to the page
   res.render('boruto shippuden',{
   style: 'review.css',
   style2: 'post.css',
   });
 });
//should have the series name as route before "reader"
app.get('/two_pieces_reader', function(req, res) {
  // data needed to insert to the page
  res.render('two pieces reader',{
  style: 'review.css',
  style2: 'post.css',
  });  
});
app.get('/boruto_shippuden_reader', function(req, res) {
  // data needed to insert to the page
  res.render('boruto shippuden reader',{
  style: 'review.css',
  style2: 'post.css',
  });  
});
app.get('/oda_nobunaga', function(req, res) {
  // data needed to insert to the page
  res.render('oda nobunaga')
});
app.get('/masashi_kissmoto', function(req, res) {
  // data needed to insert to the page
  res.render('masashi kissmoto')
});
app.get('/latest_updates', function(req, res) {
  // data needed to insert to the page
  res.render('updates')
});
app.get('/register', function(req, res) {
  // data needed to insert to the page
  res.render('register')
});
app.get('/user_404', function(req, res) {
  // data needed to insert to the page
  res.render('user404')
});
app.get('/new_story', function(req, res) {
  // data needed to insert to the page
  res.render('write',{
    style: 'review.css',
    style2: 'post.css',
    });  
  });
/**
  To be able to render images, css and JavaScript files, it's best to host the static files
  and use the expected path in the data and the imports.

  This takes the contents of the public folder and makes it accessible through the URL.
  i.e. public/css/styles.css (in project) will be accessible through http://localhost:3000/css/styles.css
**/
app.use(express.static('public'));

// Listening to the port provided
app.listen(port, function() {
    console.log('App listening at port '  + port)
  });